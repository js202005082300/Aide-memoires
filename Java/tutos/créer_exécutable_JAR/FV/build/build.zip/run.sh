#!/bin/bash
java -jar prog.jar