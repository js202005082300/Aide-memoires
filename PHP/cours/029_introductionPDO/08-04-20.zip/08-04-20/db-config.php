<?php
$DB_DSN = 'mysql:host=localhost;dbname=fv_database';
$DB_USER = 'root';
$DB_PASS = '';