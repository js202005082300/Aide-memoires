<!--
    PHP #29 - introduction PDO
    https://www.youtube.com/watch?v=ZXekAnqLwe0
    Tout sur le paramétrage et la connexion à une base de données SQL via 
    l'interface PDO (PHP Data Objects) utilisable en PHP.
-->

<?PHP

//phpinfo();
//exit; // exit directement pour ne pas exécuter le reste de la page.

/**
 *  Intro
 *  -----
 *  PDO (PHP Data Objects) : interface qui permet de manipule nos données peut importe 
 *  le système de gestion de base de données utilisé.
 * 
 *  Substituant PHP à PDO : 
 *      * mysql_connect -> obsolète depuis PHP 5.5. Toutes les fonctions mysql_...
 *          ne permettent plus d'intérroger une base de données MySQL.
 *      * mysqli_connect -> équivalent à mysql_connect qui fonctionne avec
 *          le paradigmme objet et utilisé pour MySQL sous PHP 7 sans problème.
 * 
 *  PDO est une interface qui apporte une couche d'abstraction. PDO peut intérroger 
 *  une base de données MySQL, postgreSQL, Oracle, etc. C'est un avantage par rapport
 *  à mysqli_connect qui ne sait intérroger qu'une seule base de données. On retrouve 
 *  les mêmes méthodes pour intéroger un SGBD.
 */

/**
 *  #1# Se connecter avec l'interface PDO.
 *  --------------------------------------
 *  On essaye de se connecter à la base de données et si ca n'as pas fonctionné, 
 *  on leve une exception, on retourne une erreur et suivant le message affiché,
 *  on pourra travailler dessus.
 * 
 *  On crée ensuite une instance de PDO pour obtenir un objet PDO sur lequel on 
 *  va pouvoir travailler.
 * 
 *  Les paramètres de PDO() :
 *      -> le driver, le pilote de base de données à utiliser (mysql, postgresql, oracle, etc) ;
 *      -> l'identifiant ;
 *      -> le mot de passe sql.
 * 
 *  Recommandation :
 *      -> Les paramètres (3 chaînes) ne doivent pas être mise en dure ($DB_DSN, $DB_USER, $DB_PASS)
 *      -> (Mieux) sortir ces éléments de configurations dans un fichier à part (require).
 *          -> fonction qui requiere obligatoirement un fichier (db-config.php) dans lequel
 *              se trouve les infos pour se connecter à la base de données ($DB_DSN, $DB_USER, $DB_PASS).
 * 
 *  Créer le fichier 'db-config.php' dans lequel on met :
 *      -> soit les variables ($DB_DSN, $DB_USER, $DB_PASS) ;
 *      -> soit un tableau associatif ;
 *      -> soit des constantes : define().
 * 
 *  C'est un peu plus sécuriser de mettre les données de connection dans un fichier à part.
 * 
 *  Suivant l'identifiant/mdp mis en place, on complète nos variables.
 *      -> $DB_DSN prend un format particulier => 'mysql:host=localhost;dbname=fv_database';
 *          -> ne pas mettre d'espace.
 *          -> après les deux points, l'hôte sur lequel se connecter (localhost, nom de domaine, etc.).
 *          -> indiquer sur quel base de données on veux se connecter (autrement devrait on le spécifier manuellement ?).
 *              
 *  Appeler les 3 informations séparé par des virgules dans PDO() et afficher un message de connexion réussie.
 * 
 *  En résumé,
 *      Si on arrive sur le echo et que le message s'affiche c'est que la connexion à réussie
 *      sinon une Exception va être levée par l'instanciation new PDO(), le constructeur.
 *      cela nous retourne dans le catch{} car on capture l'Exception qui sera éventuellement levée.
 *      Enfin on affichera l'érreur qui survient.
 * 
 *  On démarre notre serveur Apache c:\MyWANP\apache\bin\httpd.exe et on laisse tourner la page.
 *  On met localhost dans la barre d'adresse.
 *  
 *  Rappel :
 *      -> Nous avons installer notre serveur Apache, serveur web.
 *      -> Nous avons installer notre interprêteur PHP.
 *      -> Nous avons configurer.
 *      -> Nous avons installer MySQL.
 *      -> Nous avons configurer la création du répertoire Data.
 *      -> Nous avons mis en place un utilisateur (root) sur lequel on pouvais se sonnecter.
 *      -> Nous avons vu comment créer de nouveaux utilisateurs.
 * 
 *  ERREUR: could not find driver
 *  
 */

require 'db-config.php';
//$DB_DSN = 'mysql:host=localhost;dbname=fv_database';
//$DB_USER = 'root';
//$DB_PASS = '';

try
{
    $PDO = new PDO($DB_DSN, $DB_USER, $DB_PASS); // Instancier la classe PDO($DB_DSN, $DB_USER, $DB_PASS).
    echo 'Connexion &eacute;tablie !';
}

catch(PDOException $pe)
{
    echo 'ERREUR : '.$pe->getMessage();
}

/**
 *  #1# Activer le driver PDO.
 *  --------------------------
 *  ERREUR: could not find driver -> Il manque le driver MySQL pour se connecter.
 * 
 *  Appeler phpinfo() 
 *      -> voir si on est à jour (voir PHP tutoriel).  
 *      -> voir si mon driver est activé (rubrique PDO drivers : no value).
 *  
 *  Par défaut, PDO n'est pas activé. Néanmoins il est déjà installé sur les version de PHP actuel.
 *  Tous les fichiers pdo_mysql sont présent dans C:\MyWamp\php\ext mais ne semble pas activé.
 *  
 *  Activer ces fichiers dans C:\MyWamp\apache\php.ini en recherchant l'extension pdo_mysql.
 *  (Toutes les extensions sont commenter par défaut car c'est inutile de charger tout les drivers 
 *  en même temps).
 *      -> décommenter mysqli (si nécessaire pour la suite).
 *      -> décommenter (pdo_mysql).
 * 
 *  Relancer le serveur quand on a activé l'extension (à chaque modification).
 */

phpinfo();
exit; // exit directement pour ne pas exécuter le reste de la page.

/**
 *  #2# Configurer le chemin à php_pdo_mysql.dll.
 *  ---------------------------------------------
 *  -> configurer PHP pour accéder au fichier : C:\MyWamp\php\ext\php_pdo_mysql.dll
 *  -> décommenter extension_dir = "ext" pour Windows dans C:\MyWamp\apache\php.ini
 *  -> remplacer par extension_dir = "C:/MyWamp/php/ext" (Attention aux anti-slash) 
 *      pour trouver le chemin en absolu.
 *  -> couper le serveur et le relancer.
 *  -> actualiser la page sur le navigateur.
 *  -> phpinfo() affiche que le driver MySQL a été reconnu et activé.
 *  -> A l'heure actuel, aucune connexion ne peut être établie car l'ordinateur cible
 *      l'a expréssement refusé.
 *      => C'est normal. On a démarré le serveur Apache mais pas le serveur MySQL.
 * 
 * 17:00
 */
