<?php
if(!isset($_COOKIE['lang']) || empty($_COOKIE['lang'])) // Créer le cookie si il n'existe pas ou bien qu'il est vide.
    setcookie('lang', 'fr', time() + 3699 * 24 * 365, null, null, false, true); // Cookie définie la langue choisie par un utilisateur.
/**
 *  #0# Intro.
 *  Créez des cookies en PHP pour stocker des données (non sensibles) via vos navigateurs web.
 *  Vidéo : https://www.youtube.com/watch?v=yED9q_chp8c
 *  Cookies : 
 *      -> un cookie est un fichier texte enregistré au niveau du navigateur web.
 *      -> il permet de stocker des informations mais pas des informations de sécurités ou confidentielles.
 *      -> sa valeur peut être modifiée par un utilisateur via le navigateur ou une extension.
 *      -> un pirate peut récupérer le contenus de certains cookies et s'en servier.    
 *      -> Cookies >< sessions pour stocker les informations de certains cookies.
 *      -> Exemple de stockage : 
 *              - la langue de préférence d'un utilisateur.
 *              - le thème choisi dans un site multithèmes.
 *              - le fuseau horraire.
 */


/**
 *  #1# setcookie() : créer un cookie.
 *      -> fonction qui doit être placée avant tout code HTML et tout espace blanc.
 *      -> besoin de se faire avant toute requête HTTP.
 *      -> les visites sur le site sont personnalisées à chaque fois.
 *      @params :
 *          -> nom du cookie : 'lang'
 *          -> valeur du cookie : 'fr'
 *          -> Temps avant expirétion du cookie : time() + 3699 * 24 * 365
 *              -> time() = fonction du temps passé depuis le temps UNIX.
 *              -> 3699 * 24 * 365 => cookie valable 1 an.
 *          -> chemin du cookie : null.
 *          -> nom du domaine ou est appliqué le cookie : null.
 *          -> sécurisé le cookie avec https : false.
 *          -> accès au cookie ne se fait qu'en http et pas en JavaScript : true.
 *              -> JavaScript peut conduire à des failles de sécurité. 
 *              -> TOUJOURS à true pour empêcher la récupération de cookie via du JavaScript.
 * 
 *          
 *      < ?php <!-- fonction placée tout en haut...
 *      setcookie('lang', 'fr', time() + 3699 * 24 * 365, null, null, false, true);
 *          ...
 * 
 */

/**
 * #2# afficher le contenu d'un cookie.
 *      @variables super globales : 
 *          - $_GET ... transmissions des données en PHP ...
 *          - $_POST
 *          - $_COOKIE : permet de récupérer toutes les valeurs sur les cookies que nous avons.
 *      -> Attention lors de l'affichage de la valeur d'un cookie car un cookie peut être modifié par un utilisateur.
 *          Quelqu'un pourrait injecter un code JavaScript à la place du cookie qui s'interprêterais au niveau du navigateur.
 * 
 */

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?= $title ?></title>
</head>
<body>
    <h1>Les cookies en PHP</h1>
    <!-- Eventuellement tester si le cookie existe avec un is_set() et !empty().-->
    <p>Langue de l'utilisateur : <?= htmlspecialchars($_COOKIE['lang'])?></p> <!-- Mettre le nom du cookie entre crochets.-->
</body>
</html>

<!--
    Sécurité supplémentaire : 
        Pour éviter qu'un petit malin mette ru (russe) :
            -> ajouter une liste de langues valides (fr, en).
            -> afficher un message d'erreur pour dire que ca ne foncionne pas.
            -> appliquer une langue par défaut.
        Pour paramètrer (thème, langue) un site avec des valeurs de cookies :
            -> TOUJOURS vérifier que la valeur du cookie fait partie des valeurs autorisées.
-->