<!--
    PHP #25 - classe abstraite
    https://www.youtube.com/watch?v=Wh0aRwvZigc
-->

<?PHP
/*
 *  #1# Création d'une classe mère.
 *  -------------------------------
 *  final au début de la méthode signifie qu'on ne peux pas redéfinir la méthode dans la classe fille.
 *  => toutes les classes disent qu'elles sont la mère.
 */

class Mere
{
    protected $_name; // déclarer un attribut en protected car on va faire une classe fille.
    public function __construct($name) // Définir le constructeur public avec un nom comme information.
    {
        $this->_name = $name; // Stocker l'information dans un attribut avec le constructeur.
    }

    final public function hello() // Déclaration d'une fonction simple.
    {
        echo 'Coucou, je suis la mère : '.$this->_name.'<br>'; // fermer la balise PHP avec du code HTML.
    }
}

/*
 *  #2# Création d'une class fille.
 *  -------------------------------
 *  le mot clé final signifie que la classe fille est une classe finale.
 *  Cette classe ne pourra pas être étendue.
 */

final class Fille extends Mere // extension de la classe mère.
{
    private $_otherName; // attribut en plus. Spécialisée par rapport à la classe mère.
    
    public function __construct($name, $otherName) // Surcharger le constructeur, rajouter des élements en plus.
    {
        parent::__construct($name); // appeler le constructeur parent avec les élements qu'il doit prendre.
        $this->otherName = $otherName; // nouvel élement.
    }
    /*
    Avec le mot clé final sur la méthode, on ne peux pas redéfinir la méthode (overwrite).
    --------------------------------------------------------------------------------------
    public function hello() // redéfinir, réécrire la méthode hello(). La fille n'est pas la mère.
    {
        echo 'Je suis la Fille : '.$this->_name.' '.$this->_otherName.'<br>';
    }
    */
}

/*
 *  #3# Création d'une class petite fille.
 *  -------------------------------
 *  Fatal error car petite fille ne peux pas hériter de la classe finale Fille.
 */

/*class PetiteFille extends Fille // PetiteFille étend la classe Fille.
{

}*/

$mama = new Mere('Katie');
$mama->hello(); // Appel à la méthode avec le nom Katie.
$fifille = new Fille('Maude', 'LANISSIE');
$fifille->hello();

/*
 *  #4# Créer une classe abstraite.
 *  -------------------------------
 *  Schéma : La classe Carte est une classe abstraite.
 *  classe abstraite est une classe un peu vague.
 * 
 *  On a définis des informations, des propriétés, des méthodes surtout mais 
 *      on ne sait pas comment elles vont fonctionner.
 * 
 *  Dans la programmation, c'est une classe qu'on ne va pas pouvoir instancier.
 *  -> On ne va plus pouvoir créer d'objet de classe Mere.
 *  -> Pas d'implémentation. On définis juste la méthode. -> on ne pourra pas l'utiliser si elle n'as pas été implémentée.
 *  -> protected car ca va être définis par la suite.
 *  -> On dit que la classe Mere est capable de dire hello() mais on ne sait pas comment.
 *  -> On ne pourra jamais créer de carte simple dans notre jeu. -> abstrat sert à avoir un modèle un peu vague.
 *  -> Les cartes de notre jeu sont des cartes à spécialisation (carte fusion, terrain).
 *  -> On travaille avec que des cartes concrètes.
 *    
 */

abstract class Mere_02
{
    abstract protected function hello(); // méthode hello() non implémentée.
}

/*
 *  #5# Redéfinir une méthode abstraite.
 *  ------------------------------------
 *  Généralement, on redéfinis la méthode en public.
 */

class Fille_02 extends Mere_02
{
    public function hello() // public : remettre une visibilité un peu moins stricte.
    {
        echo 'Hello, je suis la Fille'.'<br>';
    }
}

/*
 *  #6# Instanciation d'une méthode abstraite redéfinie.
 *  ----------------------------------------------------
 */

//$obj = new Mere_02(); // On a pas le droit d'instancier une classe abstraite.
$obj = new Fille_02(); 
$obj->hello(); // appeler la méthode hello() qui était très vague, très abstraite au niveau de la classe mère.

/*
 *  #5# Le principe d'abstraction.
 *  ------------------------------
 *  Plusieurs entités peuvent être abstraite au début. Par exemple, Gestionnaire, on ne sait pas ce qu'il gère au début.
 *  Le principe d'abstraction de classe, c'est quand on ne donne pas le modèle, la marque si on me demande ce que j'ai comme ordinateur,
 *      comme voiture, etc. Ce n'est pas assez concret, c'est trop abstrait.
 * 
 *  Notre classe abstraite (carte, Gestionnaire), 
 *      -> on ne pourra jamais instancier d'objet de cette classe.
 *      -> On appelera jamais de méthode de cette classe.
 *      -> On redéfinis, spécialiser tout dans les classes filles (carte son, carte piège).
 *          => créer des classes concrètes.
 *   
 *  Le principe d'abstraction est lié au paradigme de la programmation objet (PHP, Python, C++, Java) mais pas tout les POO.
 * 
 *  En résumé, on a une classe abstraite avec le mot clé abstract et on définis des méthodes abstraites dans Mere_02, éventuellement en protected.
 *  Dans les classe Fille_02, on redéfinis obligatoirement les méthodes abstraites, en public.
 *  On est obligé car la classe mère n'a aucunes implémentation, on est obligé de redéfinir.
 *  Enfin, on implémente les méthodes, chaque classe fille sera différente avec sa manière à elle de parler.
 *  
 */

/*
 *  #7# Exemple.
 *  ------------
 *  On implémente les méthodes, chaque classe fille sera différente avec sa manière à elle de parler.
 */

abstract class Mere_03
{
    abstract protected function parler($message); // méthode abstraite parler().
}

class Fille_03 extends Mere_03
{
    public function parler($message) // redéfinir la classe fille.
    {
        echo $message.'<br>';
    }
}

$obj = new Fille_03(); // la classe fille parle de manière concrète, là où la classe mère est abstraite.
$obj->parler('Bonjour'); // la classe fille parle de manière concréte là où on ne sait pas comment la classe mère parlerais.
$obj->parler('Comment ça va ?'); 


/*
 *  #8# Paramètre optionnel.
 *  ------------------------
 *  Il est obligatoire de mettre une valeur par défaut avec =. Sinon erreur de comptabilité.
 */

abstract class Mere_04
{
    abstract protected function parler($message); 
}

class Fille_04 extends Mere_04
{
    public function parler($message, $param = 10) // redéfinir la classe fille.
    {
        echo $message.' | '.$param.'<br>';
    }
}

$obj = new Fille_04();
$obj->parler('Bonjour', 8);
$obj->parler('Comment ça va ?', 14);
?>
