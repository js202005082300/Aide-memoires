<?php
/**
 *      Vidéo : https://www.youtube.com/watch?v=UgJ21BAt-y0
 * 
 *      Les sessions :  
 *          - c'est comment enregistrer des données utilisateur et les converser 
 *              tout le long de sa navigation via la superglobale $_SESSION. 
 *          - C'est stocker des informations sécurisé ou non (même privé), tout au
 *              long de la navigation de l'utilisateur sur les pages du site web. 
 *              C'est plus qu'un cookie ou les données d'un formulaire transmisent à une page 
 *              de résultat qui sont ensuite perdues. $_GET et $_POST ne sont pas sauvegardé quand
 *              on a passé la page de résultats. $_SESSION reste plus longtemps.
 *          -> Données utilisateurs enregistrées sous forme de variables de session 
 *              qui pourront transiter d'une page à l'autre du site. Tant que la 
 *              session est en cours, on aura accès à ces informations. 
 * 
 *      Sécurité :
 *          -> La session est accessible que pour l'utilisateur qui a ces données. 
 *              Cela permet d'avoir des données sécurisées.
 *      
 *      Applications :
 *          - stockage d'un panier sur un site e-commerce.
 *          - stockage de données comme un identifiant.
 *          - enregistrer informations sur les actions par un utilisateur.
 *          - créer un système de notifications. 
 *              -> Quand une action s'est produite, on peux lui 
 *                  notifier tel ou tel action en JavaScript.
 *      
 *      Processus :
 *          -> le système de session va enregistrer un cookie où il va sauvegarder
 *              un identifiant de session.
 * 
 *      Créer une session :     c'est créer un cookie qui va choisir un identifiant 
 *              pour identifier la session en cours de l'utilisateur.
 *          -> On peux manipuler cet identifiant de session, ces données parfois sensibles.
 *          -> Ces données sont enregistrées dans le navigateur.
 *      
 *      PHPSESSID :     Nom de l'identifiant de session en PHP.
 *      
 *      $_SESSION :     variable superglobale qui contient toutes une série de données.
 * 
 *      session_start() : fonction pour démarrer une session.
 *          -> Se met :
 *              -   avant tout code PHP et HTML, tout espace blanc, tout texte (comme pour setcookie()) ;
 *              -   à chaque page où on veut utiliser les variables enregistrées en session ;
 *          -> Elle permet ensuite de sauvegarder des informations en passant par la variable superglobale $_SESSION.
 *          -> Cette variable a la durée de vie de la session.
 *          -> retourne true en cas de réussite et false en cas d'erreur.
 * 
 *      session_destroy() : fonction pour terminer la session.
 *          -> Les paramètres de PHP définisse la fin de la session accèssible dans les configurations.
 *          -> L'utilisateur qui quitte son navigateur met également fin à la session.
 * 
 *      unset() : fonction qui enlève la définition d'une variable de session.
 *          -> Juste pour les variables en particulier, JAMAIS sue $_SESSION tout seul.
 * 
 *      hash_algos() : retourne un tableau d'identifiants du type de hash que l'on veux (voir fichier de config php.ini)
 *          session.hash_function = "sha256" OU session.hash_function = 5 DANS php.ini
 * 
 *      Initialiser une session. -> Avant tout code HTML et espace blanc.
 *      session_id() : retourne un identifiant de session sinon retourne une chaîne vide.
 *                      -> retourne true en cas de réussite et false en cas d'erreur.
 *      session_regenerate_id(true) : @param à true pour supprimer l'ancien identifiant.
 * 
 *      Mettre fin à la session.
 *      session_unset() : supprimer toutes les variables enregistrées en session.
 *      session_destroy() : supprimer la session.
 *      
 *      Niveau supérieur de suppression.
 *      session_write_close() : Met fin à tout et supprime encore la session.
 * 
 *      Modifier le cookie d'identifiant de session.
 *      session_name() : récupère ou modifie le nom de la session.
 * 
 *      Niveau bourrin de suppression.
 *          -> Application : utiliser setcookie() de session_name() et on lui met une valeur vide.
 *                              et on lui met un temps d'expiration de 0 (expire tout de suite).
 *          -> sécurité en plus pour être sûr d'avoir supprimer un identifiant de session.
 *          -> Ensuite on ferait la regénération d'un nouvel identifiant :  session_regenerate_id(true);
 *      
 *      cela donne (Ne fonctionne pas) : 
 *          session_start(); // au début du fichier, avant tout code HTML.
 *          session_unset();
 *          session_destroy(); // supprime la session.
 *          session_write_close(); // on écrit la fermeture de session et on la supprimer.
 *          //Modifier le cookie.
 *          setcookie(session_name(), '', 0, null, null, false, true); // retourne session_name (créer à l'instant)) vide avec 0 temps d'expiration.
 *          session_regenerate_id(true); // regénérer un nouvel identifiant pour perdre tout ce qui a été fait avant.
 *      
 *      session_status() : fonction qui retourne 3 choses :
 *          -> 0 (PHP_SESSION_DISABLED : les sessions sont désactivées au niveau de PHP ou elles le sont par défaut et là pas de problèmes).
 *          -> 1 (PHP_SESSION_NONE : les sessions sont activées au niveau de PHP, mais on en a pas créé, pas de session en cours).
 *          -> 2 (PHP_SESSION_ACTIVE : une session est bien activée au niveau de PHP et on est en train de s'en servir).
 * 
 *      header('Location: ...') : 
 *          -> permet de faire une rédirection vers une nouvelle page.
 *          -> appelé après unset et destroy au début d'un fichier prévu pour la déconnection
 *              et après ces deux fonctions, on fait une redirection.
 *          -> ne fonctionne pas en externe si on met des liens en absolu, n'est pas sécurisé, n'est pas permis.
 *              par exemple : header('Location: http://unautresite.com/redirection.php');
 *          -> la redirection se fait avant tout code HTML sinon message d'erreur : "headers have already sent" = les en-têtes HTTP ont déjà été envoyés.
 * 
 *      Rappel :
 *          session_status()    -> 0 PHP_SESSION_DISABLED
 *                              -> 1 PHP_SESSION_NONE
 *                              -> 2 PHP_SESSION_ACTIVE
 *          session_id()
 *          session_name()
 *          Création de la session  * session_start()               avec test sur session_id.
 *                                  * session_regenerate_id(true)
 *          Fin de la session       * session_unset()
 *                                  * session_destroy()
 *          session_write_close()
 */
    //header('Location: deconnection.php');
    session_start(); // en début de page et à chaque page où on veux l'utiliser.
    echo session_status();
    $_SESSION['username'] = '<strong>Fifou</strong>';
    $_SESSION['montantPanier'] = 123.67;
    unset($_SESSION['username']); // Attention ne jamais faire unset($_SESSION);

    /* #1# Initialiser une session.*/
    if(!session_id()) // si on a une chaine vide, on va pouvoir démarrer notre session pour éviter de recrer une session avec une déjà en route.
    {
        session_start(); // pensez à vérifier si session_start ne retourne pas false sinon il faut gérer les sessions via un système d'exceptions (voir les objets) ou autre.
        session_regenerate_id(true); // permet de supprimer l'ancien identifiant et être sûr qu'on part sur une session nouvelle avec le paramètre true.
    }

    // On fait des choses avec les sessions ...
    $_SESSION['username'] = 'Mog';
    $_SESSION['montantPanier'] = 255.67;
    
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?= $title ?></title>
</head>
<body>
    <h1>Sessions en PHP</h1>
    <p>Bonjour <?= htmlspecialchars($_SESSION['username']) ?></p>
    <p>Montant du panier <?= htmlspecialchars($_SESSION['montantPanier']) ?> euros.</p> 
    <!-- Ici on n'as pas enregistré de cookie.
    On a un cookie pour la variable de session mais c'est tout.
    
    Tant que la variable vient de l'utilisateur, tant qu'on est 
    pas sûr de la provenance des données, on utilise htmlspecialchars
    pour sécuriser l'affichage.

    Si l'utilisateur met du HTML ou du JavaScript, on va échapper les caractères et
    donc on aura pas l'interprêtation du JavaScript ou des balises HTML.
    -->
    <pre>
    <?php print_r(hash_algos()) ?>
    </pre>
</body>
</html>

<?php
    echo session_status();
    /* #2# Mettre fin à la session.*/
    session_unset();
    session_destroy();
    /* -------------- */
    echo session_status();
?>