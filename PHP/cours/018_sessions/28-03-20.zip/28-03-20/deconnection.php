<?php
    // Ceci est un essais personnel.
    session_start();
    session_unset();
    session_destroy();
    header('Location: redirection.php');
    //session_write_close();
    //setcookie(session_name(), '', 0, null, null, false, true);
    //session_regenerate_id(true);
?>

