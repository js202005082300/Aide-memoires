<!--
    PHP #24 - héritage
    https://www.youtube.com/watch?v=BqO7U0ed-pA
-->

<?PHP
/*
 *  L'héritage est une notion liée au paradigme de la programmation objet.
 *  Rappel schéma :
 *      -> notre application fonctionne en entité, en boites, des classes avec 
 *          leur principe de propriétés et de méthodes.
 *      -> par la suite, nous avons des liens entre ces différentes entités.
 *          => notion d'héritage.
 *  Schéma 02 : 
 *      -> les classes sont représentées par des boîtes.
 *      -> méthodes à gauche : Init(), update(), etc.
 *      -> propriétés à droite : id, nom, etc.
 *  L'exemple de Gauche : 
 *  ---------------------
 *      -> il y a une classe mère, classe de base comme Gestionnaire qui possède 
 *          des méthodes : init(), launch(), etc. Par principe, tous les 
 *          gestionnaires possèdent au moins ces services là.
 *      -> si on veux que notre application gère des images et des vidéos, du son, 
 *          du réseau, etc. il faut étendre l'utilisation de notre gestionnaire, 
 *          classe mère, en créant des classes filles. On dit que les classes filles
 *          vont héritées de la classe mère.
 *      -> Par héritage, on entend que toutes les classes filles possèderont toutes les
 *          méthodes de la classe mère. Et également les propriétés, absente de la classe 
 *          mère dans ce cas. 
 *      -> On dit que les classes filles sont spécialisées par rapport à la classe mère. Elle
 *          possède tout de la mère avec des choses en plus.
 *      -> L'intéret de faire de l'héritage d'apporter des fonctionnalités en plus vers les classes filles.
 *          C'est aussi de pouvoir surcharger des méthodes. 
 *          Pour le gestionnaire, on a une méthode par défaut Init() mais l'initialisation
 *          d'un gestionnaire de son ou d'image vont être différent. Si on ré-écrit les méthodes
 *          de la classe mère vers la classe fille, on va les surcharger.
 *  L'exemple de Droite : 
 *  ---------------------
 *      -> Il y a deux classes (Carte et CartePiege) avec des propriétés (id, nom, description).
 *      -> On pense à une entité carte qui est une carte de Jeu (Pokemon, Yu-Gi-Oh !).
 *      -> On peux créer une carte particulière qui est une carte piège. Elle possède les propriétés
 *          de notre classe mère (id, nom, description).
 *          En effet, si elle hérite de la classe 'carte', la CartePiege possède tout les attributs,
 *          les propriétés (et ses méthodes).
 *      -> On dit que une CartePiege a des spécialités (effet et dureeEffet) par rapport à une carte simple.
 *          On dit que CartePiege est une sorte de Carte.
 *      -> En réalité, les enfant héritent de leurs parents. Idem pour les animaux.
 * 
 */

/**
 *  Rappel de ce que l'on a appris.
 *  -------------------------------
 */
class Card
{
    protected $_name;
    private $_description;

    public function __construct($name, $description)
    {
        $this->_name = $name;
        $this->_description = $description;
    }

    public function hello()
    {
        echo 'Je suis la carte '.$this->_name.'<br>';
    }
}

$mycard = new Card('Magicien sombre', 'Un magicien aux grands pouvoirs ...');
$mycard->hello();

/**
 *  #1# Créer une classe fille (qui hérite)
 *  ----------------------------------------
 *  TrapCard va être étendue depuis la classe mère avec le mot clé extends.
 *  Elle étend la classe Card.
 * 
 *  Quand on construit notre carte fille, le système cherche un constructeur
 *  dans la classe la plus héritée et si cette méthode n'existe pas, on remonte
 *  en haut. Si PHP ne vois pas de constructeur dans la classe fille, il va 
 *  remonter à la classe mère et appeler le constructeur. C'est pareil pour 
 *  les autres méthodes.
 * 
 */

class TrapCard extends Card
{

}

/**
 *  #2# Créer une carte piège.
 *  --------------------------
 *  On crée d'abord une instance de notre carte piège.
 *  On appelle pour cette carte piège une méthode Hello().
 *  PHP recherche si on a surchargé, ré-écrit la méthode dans la classe fille, mytrapcard.
 *  Comme il n'y a pas de méthode dans cette classe, il revient à la classe parente,
 *      c'est à dire la classe parente, mère qui est Card. Enfin PHP trouve la méthode hello()
 *      et l'appelle.
 *  Dans certains cas la méthode hello() ne retourne pas la même chose qu'une simple Card. 
 *      => Redéfinir cette méthode.
 */

$mytrapcard = new TrapCard('Fosse', 'Une grande fosse qui piège tous les ennemis');
$mytrapcard->hello();

/**
 *  #2# Redéfinir une méthode.
 *  --------------------------
 *  La méthode appelée est celle de la classe fille cette fois ci.
 *  PHP cherche toujours dans la classe où on se trouve et s'il ne trouve pas
 *      il va revenir à la classe parente et ainsi de suite.
 *  L'héritage peut remonter très loin dés lors qu'on crée une classe sous fille
 *      (SpecialTrapCard), etc. 
 *  Si jamais la méthode n'existe pas, on recevra un message d'erreur évidemment.
 */

class TrapCard_02 extends Card
{
    public function hello()
    {
        echo 'Je suis une TrapCard !<br>';
    }
}

class SpecialTrapCard extends TrapCard_02
{

}

$mytrapcard_02 = new TrapCard_02('Fosse', 'Une grande fosse qui piège tous les ennemis');
$mytrapcard_02->hello();

/**
 *  #3# Le mot clé protected.
 *  --------------------------
 *  Le mot clé private fait que l'information est privée partout.
 *  Par exemple si TrapCar essaye d'appeler $this->_name, PHP ne trouvera pas de
 *      propriété name. 
 * 
 *  Name est un attribut privé. Tout ce qui est privé appartient à la classe où c'est définis.
 *  On ne veux pas que les classes filles accèdent à la classe Card. 
 *  C'est pourquoi, on donne le mot clé protected aux attributs d'une classe mère pour
 *      donner l'accès aux classes filles.
 * 
 *  protected rend les attributs privé pour tout le monde sauf pour les classes filles donc
 *      les classes qui en héritent.
 * 
 *  Si il n'y a pas de liaison d'héritage entre les deux classes, le mot clé protected n'y changera rien.
 *  
 *  Si une classe mère va être utilisée en héritage, on peux passer les attributs en héritage pour
 *      y avoir accès. Cela gardera le coté privé pour le reste mais le coté public pour les classes filles.
 * 
 */

class TrapCard_03 extends Card
{
    public function hello()
    {
        echo 'Je suis une autre TrapCard !<br>';
        echo $this->_name;
    }
}

$mytrapcard_03 = new TrapCard_03('Fosse', 'Une grande fosse qui piège tous les ennemis');
$mytrapcard_03->hello();

/**
 *  #4# Redéfinir le constructeur dans la classe fille.
 *  ---------------------------------------------------
 *  La classe fille ne va pas réutiliser le constructeur de la classe mère (=redefinir __construct).
 *  La nouvelle classe fille va avoir son propre constructeur, spécialisée. 
 *  Elle est spécialisée car elle reprend tout ce que la classe mère a dans son constructeur plus ces propres éléments.
 *  Elle a un élément en plus par rapport à la classe mère.
 * 
 *  On peux appeler un constructeur ou deux.
 *  En effet, on réécrit $this->_name et $this->_description alors qu'on les as déjà dans la classe mère.
 *  
 *  La solution est d'appeler deux constructeurs et d'appeler dans le constructeur de la fille, la partie 
 *  qui est déjà la même que la classe mère.
 *      => utiliser le mot clé "parent" et l'opérateur de résolution de portée ::
 *  Ca permet d'éviter les répétition de code.
 * 
 *  Surtout si un jour, on change le constructeur de la classe mère (vérification, conditions, etc),
 *  nous n'aurons pas besoin de le changer dans les classes filles.
 *  
 *  Ainsi on éviter de ré-éditer dans la classe fille si un jour on change la classe mère.
 * 
 */ 

class TrapCard_04 extends Card
{
    private $_effect; // on ne va pas créer une classe qui va hériter de TrapCard donc on met un attribut privé.

    public function __construct($name, $description, $effect)
    {
        //$this->_name = $name;
        //$this->_description = $description;
        parent::__construct($name, $description); // appeler volontairement le constructeur de la classe mère.
        $this->_effect = $effect;
    }
    
    public function hello()
    {
        echo 'Nom : '.$this->_name.'<br>';
        echo 'Description : '.$this->_description.'<br>';
        echo 'Effect : '.$this->_effect.'<br>';
    }
}

$mytrapcard_04 = new TrapCard_04('Fosse', 'Une grande fosse ...', 'Detruit tous les ennemis sur le terrain'); // troisième argument au constructeur (effect).
$mytrapcard_04->hello();
echo '<br><br>';
$myotherCard = new Card('Test', 'ma description'); // ici on recrée une card mère sans problème.
$myotherCard->hello();

/**
 *  #5# Conclusion.
 *  ----------------
 *  
 *  Notions :
 *      -> On a vu des changements sur les mots clé : private, public, protected.
 *      -> Le constructeur fille peut appeler le constructeur mère : parent::__construct().
 *      -> On peux redefinir, surcharger des méthodes.
 * 
 *  Cas humain :
 *      L'héritage des parents avec une propriété de couleur des yeux en protected.
 *      Le génome redéfinis la couleur, on aura pas forcément les yeux bleux.
 *      Le pourcentage des deux parents va redéfinir notre couleurs des yeux.
 *      C'est pareil pour une méthode, on peux redéfinir la couleur des yeux, etc.
 *      La classe mère aura peut être un comportement différent de la classe fille mais elle
 *          va réutiliser les mêmes méthodes, c'est pourquoi on fait une redéfinition de la méthode.
 *      La méme méthode hello() va avoir deux comportement différent.
 * 
 *  Exercice : 
 *      On fait une classe animale avec son âge, sa nouriture, son nom, etc.
 *      Après des classes filles : une classe chat, un aigle, dauphin, etc.
 *      Le dauphin aura des choses en plus.
 *      La classe mère est toujours un peu abstraite, on définis une entité, un card avec peu de choses.
 *      Notre carte piège avec un nom et une description, ce n'est pas suffisant, ils faut d'autres choses.
 *      C'est pourquoi on ajoute des propriétés et qu'on redéfinis des méthodes.
 *      => Par le principe de spécialisation et de redéfinition éventuelle de propriétés et de méthodes pour
 *          changer les comportements.
 */
?>