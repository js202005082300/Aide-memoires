<!--
    PHP #26 - interface
    https://www.youtube.com/watch?v=3APJu3DjbHQ
-->

<?PHP
/*
 *  Intro
 *  -----
 *  Cours sur les interfaces en PHP, pour compléter la notion de classe abstraite 
 *      et fournir un contrat de services avec possibilité de créer des classes 
 *      implémentant plusieurs interfaces.
 * 
 *  C'est une confusion récurente chez les développeurs de savoir quand utiliser 
 *      la notion de classe abstraite et les interfaces.
 * 
 *  Classe abstraite : 
 *      -> classe qui ne s'instancie pas.
 *      -> factoriser du code 
 *          -> On rassemble les répétition de codes en travaillant avec des méthodes.
 *          -> On a des méthodes abstraites qui obligent dans les classes qui étendent 
 *             cette classe abstraite à implémenter ces méthodes.
 *      -> une classe ne peut qu'étendre une seule autre classe.
 *  
 *  Interface :     -> représente une API (Application Programmable Interface)
 *                      -> implémenter des recettes tel un menu dans un restaurant.
 *                      -> implémentation multiple.
 *                  -> permet de fournir un "contrat de services".
 *                  -> une classe peut implémenter plusieurs interfaces.
 * 
 *  Utilisation :
 *      -> utiliser une classe abstraite pour factoriser du code pour 
 *          implémenter dans une classe fille. On ne s'en sert pas pour
 *          fournir une API, quelque chose de haut niveau avec un ensemble
 *          de services.
 *      -> utiliser une interface si on prévoit d'avoir des classes 
 *          qui se servent de plusieurs entités (des interfaces plutôt 
 *          que des classes abstraites).
 *      -> utiliser une interface pour créer un forum (créer, 
 *          publier un message, etc).
 * 
 *  Si ni la classe abstraite ou l'interface ne conviennent dans le contexte 
 *  de développement. Une autre notion propre à PHP, pas à la POO, permet de combler
 *  les manques des classes abstraites et les interfaces.
 */

/*
 *  #1# Créer une interface.
 *  ------------------------
 *      -> Utiliser le mot clé interface.
 *      -> par convention, on commence par i ou I suivi du nom pour l'interface.
 *      -> permet de définir des méthodes publics. Ces méthodes ne sont pas implémentées.
 *          C'est comme une API ou encore un menu dans un restaurant qui nous présente 
 *          ce qui est disponible.
 *          Exemple : déterminer tout ce que l'on peux faire avec un article.
 *      -> l'ensemble de ces méthodes donne l'ensemble des services, un genre de contrats 
 *          de services que propose cette interface.
 * 
 *  Remarques, dans les interfaces :
 *      -> TOUJOURS mettre les méthodes en public.
 *      -> On peut définir des constructeurs.
 *      -> On peut définir des constantes.      
 */

interface IArticle // interface pour des articles.
{
    // définition de constantes ...
    const NB_ARTICLES_PER_PAGE = 10; // définir une constante dans une interface.
    public function getNbComments();
    public function create();
    public function save($author, $content);
    public function delete();
}

/*
 *  #2# Accéder à une constante d'interface.
 *  ----------------------------------------
 *  -> pas besoin de créer une classe qui implémente une interface.
 *  -> pas besoin d'instancier.
 *  -> On y accède comme dans une méthode ou attribut statique.
 */

echo IArticle::NB_ARTICLES_PER_PAGE;

/*
 *  #3# Implémenter l'interface.
 *  ----------------------------
 *  Ici on étend pas l'interface.
 *  Obligation d'implémenter toutes les méthodes de l'interface.
 *  BlogArticle va implémenter les services que propose IArticle.
 */

class BlogArticle implements IArticle
{
    // définition d'attributs ...
    public static $_attribut = '>Test'; // test d'un attribut statique.
    // définition d'un constructeur ...
    public function getNbComments()
    {
        return 15;
    }

    public function create()
    {
        echo 'Create()';
    }

    public function save($author, $content)
    {
        echo $content;
    }

    public function delete()
    {
        echo 'suppression';
    }
}

$test = new BlogArticle();
$test->create();
echo BlogArticle::$_attribut;

/*
 *  #4# Idem mais avec des méthodes abstraites.
 *  -------------------------------------------
 *  On peux mélanger une classe qui étend un autre et qui implémente une interface.
 *  Avec classe abstraite, on ne peux pas faire d'héritage multiples.
 */

abstract class AbstractArticle // interface pour des articles.
{
    abstract public function getNbComments();
    abstract public function create();
    abstract public function save($author, $content);
    abstract public function delete();
}

class BlogArticle_02 extends AbstractArticle implements IArticle
{
    public function getNbComments()
    {
        return 15;
    }

    public function create()
    {
        echo 'Create()';
    }

    public function save($author, $content)
    {
        echo $content;
    }

    public function delete()
    {
        echo 'suppression';
    }
}

/*
Regle : Impossible de faire de l'héritage multiple en PHP.

class A{}
class B{}

class OtherClass extends A, B;

Certains langages d'éxceptions où c'est déconseillé car risque de conflits
au niveau de la compilation et de l'éxécution.

Par contre, les interfaces ont été conçue comme les classes abstraites 
mais on peux faire de la multiple implémentation d'interfaces.

*/

/*
 *  #5# Implémenter plusieurs interfaces.
 *  -------------------------------------------
 *  On peux faire de l'implémentation multiple mais
 *  on ne peux pas faire de l'héritage multiple.
 */

// Un contrat qui fournit des services lié à l'article en lui même (interface pour des articles).
interface IArticle_02
{
    /* 
    API
     -> tel notre menu, pas besoin de savoir comment on crée un article, comment on le sauvegarde.
     -> permet de définir les services proposés, disponible.
    */
    public function getNbComments();
    public function create();
    public function save($author, $content); // contrat qui manipule des auteurs => implémenter l'API, les services à un auteur.
    public function delete();
}

interface IAuthor // implémentation des services liés à des auteurs.
{
    public function profile();
}

// La classe BlogArticle a besoin d'implémenter deux API, deux types de contrats.
class BlogArticle_03 implements IArticle_02, IAuthor
{
    public function profile()
    {
        echo 'Acces au profil...';
    }
    
    public function getNbComments()
    {
        return 15;
    }

    public function create()
    {
        echo 'Create()';
    }

    public function save($author, $content)
    {
        echo $content;
    }

    public function delete()
    {
        echo 'suppression';
    }
}

/**
 *  #6# API : Application Programmable Interface.
 *  ---------------------------------------------
 *      -> Contrat de services (fonctionnalités qui doivent être implémentées).
 *      -> On a juste besoin de savoir ce que l'on peux faire.
 *      -> Interface proposée par Google, Youtube, Facebook, twitter.
 *      -> abstraction, interface de très haut niveau.
 *      -> Par exemple de services, API proposés :
 *          afficher les tweets de notre compte twitter sur notre site web
 *          même si twitter ne nous appartient pas. Diffuser les tweets sur notre site web 
 *          de manière dynamique.
 *          afficher des vidéos YouTube sur notre site web grâce à son API.
 *          etc.
 */

interface IYoutube
{
    public function getVideo();
    public function subscribers();
}
