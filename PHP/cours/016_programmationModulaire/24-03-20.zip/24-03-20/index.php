<?php
/*
 *  Programmation modulaire : 
 * 
 *          -> plusieurs fichiers différents, plusieurs petits modules.
 *          -> liés entre eux par inclusion.
 * 
 *  Inclusion :
 * 
 *          -> inclure des fichiers php dans d'autres fichiers pour les utiliser.
 *          -> utiliser le contenu de fichier externe au sein du fichier principale.
 * 
 *  Fonctions d'inclusion : 4 instructions qui permettent d'inclure du code d'un fichier PHP dans un autre.
 * 
 *          #1# include : inclure le contenu d'un fichier à l'endroit où on fait appel à cette instruction.
 *                  -> si l'inclusion échoue, PHP déclenche une alerte.
 *          #2# include_once : inclure un fichier qui n'as pas déjà été inclut.
 *                  -> évite de faire des inclusions supplémentaires.
 *                  -> si l'inclusion échoue, PHP déclenche une alerte.
 *          #3# require : inclure le contenu d'un fichier.
 *                  -> si l'inclusion échoue, PHP déclenche une erreur fatal.
 *                  -> si l'inclusion échoue, REQUIRE stoppe le script complétement.
 *          #4# require_once
 *  
 *  Remarques : 
 * 
 *  -1- deux façons de faire une instruction d'inclusion comme echo en PHP.
 *          -> echo("Bonjour");
 *          -> echo "Bonjour";
 *          Choisir et conserver la même syntaxe tout au long de nos projets.
 * 
 *  -2- Tout ce qui est inclut se trouve dans l'environnement de la fonction.
 *          -> les variables de la fonction sont éffacées à la fin de la fonction.
 *          -> les variables globales sont éffacées à la fin du programme.
 */
include 'utils.php';

echo '<p>Je suis le fichier index.php</p>';

hello();

?>

<?php
require 'haut.php'; // Dans un site HTML/CSS, ceci pourrait être l'en-tête du site.
?>

<p> Un paragraphe en HTML.</p>

<?php
require 'bas.php'; // Dans un site HTML/CSS, ceci pourrait être le footer.
?>

<!--
    Application :
        -> Appeller une fonction PHP dans index.php. avec des variables pour permettre de choisir 
        la langue de la page, l'encodage de la page, le titre de la page Web, les fichiers CSS à inclure, etc.
        -> PHP est un langage de programmation qui permet de produire des pages Web beaucoup plus dynamique que HTML.
        -> PHP permet de définir des fonctions pour gérer des paramètres dynamiques pour choisir le titre d'une page en fonction.
-->