<!--
    PHP #27 - traits
    https://www.youtube.com/watch?v=ZIqKnK37y9A
-->

<?PHP
/*
 *  Intro
 *  -----
 *  Classe abstraite :  classe qui s'instancie pas.
 *                      factoriser du code.
 *                      une classe ne peut qu'étendre une seule autre classe.
 * 
 *  Interface : API.
 *              fournit un "contrat de service".
 *              une classe peut implémenter plusieurs interfaces.
 * 
 *  Trait :
 *      -> propre à PHP et pas à toute la POO (C++, Java, ...).
 *          -> certains langage n'ont que les classes abstraites (PHP les as toutes).
 *      -> permet la Ré-utilisation de code, dans des classes indépendantes/ distinctes.
 *      -> similaire à une classe.
 *      -> permet de grouper des fonctionnalités (voir exemple).
 *      -> Pas d'instanciation d'un trait (on crée pas d'objet d'un trait ou d'une classe 
 *          abstraite ou d'une interface. On crée un objet à partir d'une classe concrète).
 *      -> Avant PHP 5, le trait n'existait pas. Il est possible de ne jamais s'en servir.
 *          => tout utiliser fait qu'on obtient un code infame. => trouver le meilleur moyen 
 *          de répondre aux problèmes informatiques rencontrés.
 */

/*
 *  #1# Créer un trait.
 *  -------------------
 *  Commencer par le mot clé trait.
 * 
 *  Exemple : Quand on fait des sites complexes, on a besoin de gérer un rootage pour 
 *  le principe des url's. L'utilisateur demande, fait envoyer une url, de là, on lui 
 *  restitue la bonne page web qui correspond à notre url. Un trait peut regrouper ainsi 
 *  toutes les fonctionnalités liées au rooting.
 * 
 *  Pas de standard mais le nomage peut se faire avec un t miniscule.
 * 
 *  Pas de fonction public car on est pas dans une classe.
 */
trait tRouting // prévoir des fonctionnalitées au niveau de notre rootage.
{
    function parse()
    {
        echo 'parsing...'; // analyser une url et retourner ces composants.
    }
    function get($req)
    {
        echo $req;
    }
}

/*
 *  #2# Créer des classes.
 *  ----------------------
 *  gestion des modules de notre site suivant le principe des url's. ce qui nécessite 
 *  d'utiliser fonctionnalités du rooting, du trait que nous avons définis.
 * 
 *  Pour se faire, utiliser le mot clé use avec le nom du trait avec un point virgule à la fin.
 * 
 *  Dans ce cas, il faut imaginer tRoutung comme une sorte de bibliothèque, un module qui
 *  propose des fonctionnalités comme si c'était isolé dans un fichier. Ici mon ModuleManager va
 *  avoir besoin d'utiliser les fonctionnalités du rooting.
 */

class ModuleManager
{
    use tRouting;
}

/*
 *  #3# Créer une instance.
 *  -----------------------
 *  L'instanciation est très rapide à faire car nous n'avons pas mis de constructeur pour 
 *  simplifier.
 * 
 *  $test va chercher une méthode parse() dans ModuleManager mais il n'en trouve pas et il y a 
 *  un trait dans lequel il trouve la méthode parse().
 * 
 *  C'est de la réutilisation de code dans des classes indépendantes car ModuleManager est indépendant
 *  de tRouting.
 */

$test = new ModuleManager();
$test->parse(); // ModuleManager utilise le trait, ce qui permet d'utiliser les fonctions de tRouting.
echo '<br>';
/*
 *  #4# Créer une autre classe.
 *  ---------------------------
 * 
 *  Créer une classe pour gérer les templates.
 * 
 *  Exemple : Quand on veux gérer de l'HTML, nos page web dans des sites plus complexes. On utilise 
 *  un système de template pour que ce soit plus rapide et générer de manière dynamique. Il a besoin 
 *  d'utiliser les url's de notre site web => Donc il se sert des fonctionnalités de rootage.
 */


class Template
{
    use tRouting;
}

/*
 *  #5# Créer une autre instance.
 *  -----------------------------
 *  Utiliser une vue pour HTML via le système de Template.
 *  On remarque que Template et ModuleManager sont des classes indépendantes (elles gèrent des choses différentes)
 *  mais elles sont capables d'utiliser les fonctionnalités groupées du trait.
 *  => ça permet de réutiliser du code dans des classes indépendantes.
 */

$html = new Template(); // faire une instance.
$html->get('news/mon-premier-article'); // passer par un trait pour utiliser une méthode.

/*
 *  #6# Changer la visibilité au niveau des méthodes du trait.
 *  ----------------------------------------------------------
 *   Changer la visibilité des fonctions (notion de visibilité abordés avec les accesseurs).
 *   On veux mettre parse dans une autre propriété de visibilité.
 *   Ce n'est plus public, mais parse passe en protected.
 *   Si on a une classe fille qui étend Template, on pourra utiliser parse as protected
 *   mais on ne pourra pas utiliser parse as private avec notre classe fille.
 */

trait tRouting_02
{
    public function parse()
    {
        echo 'parsing...';
    }
    public function get($req)
    {
        echo $req;
    }
}

class Template_02
{
    use tRouting_02{parse as protected;} // mettre parse dans une autre propriété de visibilité.
}

/*
 *  #7# Un trait peut utiliser un autre trait.
 *  -------------------------------------------
 *  On fait simplement un usage de fonctionnalité.
 */

trait tOther
{
    use tRouting;
    // autres fonctions ...
}

/*
 *  #8# Un trait peut faire référence à une classe.
 *  -----------------------------------------------
 *  Au niveau de l'utilisation, des déclarations/instanciations.
 *  Exemple : Si on a une classe définie avant un trait qui en fait usage après,
 *  on pourrais très bien à l'intérieur d'une fonction, faire réfèrence à une classe parente
 *  (trait avec une classe parente -> rare) en utilisant le mot clé parent (puis opérateur de résolution 
 *  de portée) puis on ajoute la méthode d'une classe particulière.
 *  
 */

trait tOther_02
{
    function someFunction()
    {
        parent::myMethod;
    }
}

/*
 *  #8# Un trait est similaire à une classe.
 *  -----------------------------------------------
 *  Un trait peut contenir des variables, des attributs
 *  car un trait fonctionne comme une classe.
 * 
 *  Un trait peut également contenir des méthodes statiques
 *  comme dans une classe.
 * 
 *  Un trait peut également contenir des méthodes abstraites.
 *  pour lequel on implémente rien, ce qui oblige toute classe 
 *  qui utilise le trait à implémenter cette méthode qui est
 *  abstraite à la base.
 *  
 */

trait tRouting_03
{
    public static function parse()
    {
        echo 'parsing...';
    }
    abstract public function truc(); // Rien implémenter.
}

class ModuleManager_03
{
    use tRouting_03;
    public function truc() // obligation d'implémenter cette méthode.
    {

    }
}

tRouting_03::parse(); // faire l'utilisation de manière statique comme pour une classe.
$test = new ModuleManager_03();
$test->parse();

/*
 *  Mélange de notion de classe mère, d'héritage alors qu'il n'y a pas d'extension ici.
 *  On a juste un usage.
 *  Mèle les fonctionnalités des classes, les fonctionnalités des simples fonctions
 *  dans le fait de modulariser notre code et le fait de grouper.
 * 
 *  2 Règles super importantes sur les traits :
 *      -> Un trait groupe des fonctionnalités.
 *      -> Il permet de réutiliser du code dans des classes indépendantes.
 * 
 *  Le reste est logique (pas d'instanciation, similaire à une classe).
 */

?> <!-- éviter les problème de chevauchement..-->

    