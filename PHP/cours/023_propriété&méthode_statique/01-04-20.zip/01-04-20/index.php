<!--
    PHP #23 - propriété et méthode statique
    https://www.youtube.com/watch?v=Wd4FDAR9nHg
-->
<?php
/**    
 *  Rappel : 
 *  ---------
 *      Pour créer une classe, on a un ensemble de 
 *          -> propriétés qui la définis (private $_name & private $_speed).
 *          -> méthodes qui permettent de définir des service (ce qu'elle est capable de faire).
 *  
 *      On instancie une classe pour créer un objet, stocké dans une variable.
 *      A partir de ces variables, on peut utiliser ces méthodes.
 *          -> on crée un véhicule en lui spécifiant un nom, une vitesse.
 *          -> on appel la méthode move() pour indiquer le nom du véhicule et à quel vitesse, il se déplace.
 * 
 *      En résumé, on a une classe, on instancie cette classe pour créer des objets et depuis ces objets
 *      on accède (et ou modifie) les attributs avec les accesseurs. Et faire appel aux méthodes pour utiliser
 *      les services de la classe.
 */

class Vehicule
{
    private $_name;
    private $_speed;

    public function __construct(string $name, int $speed)
    {
        $this->_name = $name;
        $this->_speed = $speed;
    }

    public function move()
    {
        echo 'Le Vehicule '.$this->_name.' se deplace a '.$this->_speed.'km/h.<br>';
    }
}
// Nous sommes en dehors de la classe.
$obj1 = new Vehicule('xc450', 650);
$obj1->move();

/**
 *  Autre méthode : 
 *  ----------------
 *      Méthode sans passer par l'instanciation de classe, passer par des objets :
 *      
 *      Admettons qu'on veux faire une classe utilitaire, de service (une classe de connection 
 *      à une base de données, une classe d'enregistrement dans un fichier spécifique). c'est à dire
 *      une simple classe avec quelques petites fonctions. 
 * 
 *      Dans ce cas, on peux définir des propriétés et des méthodes statiques. Nous n'aurons pas 
 *      besoin de créer d'objets, d'instancier cette classe.
 */

/**
 *  #1# Créer une classe d'utilitaire pour la base de données.
 *  ----------------------------------------------------------
 *  Créer une classe d'utilitaire qu'on ne pourra pas instancier, qui n'aura pas de constructeur.
 *  On instancie pas une classe qui a des éléments statiques.
 *  on fait simplement une méthode statique avec le mot clé static devant notre méthode.
 * 
 *  2 choix après :
 *      -> au lieu de créer un objet, on peux utiliser la méthode directement.
 *      -> avoir qu'une seule instance et toujours travailler avec cette instance là pour
 *          éviter de surcharger le nombre d'objets qui se connecteraient à la base de données.
 *          Alors qu'on pourrait utiliser la même liaison pour faire toutes ces connections.
 * 
 *      
 */

class Database_01
{
   public static function connect()
   {
       echo 'Je me connecte ...';
   }
}

/**
 *  #2# Appeler une méthode static.
 *  -------------------------------
 *  Au lieu de créer une variable dans lequel on va créer une instance de la classe pour un nouvel objet,
 *  on va spécifier le nom de la classe et un operateur de résolution de portée (::) et terminer par le nom
 *  de la méthode appelée.
 * 
 *  Ainsi, on appel de la méthode statique sans avoir créer l'instance de l'objet.
 *      => on ne pourra pas créer de pseudo variable $this qui existe seulement
 *          quand une classe a été instanciée.
 *  NB : 
 *      $this = variable qui contient l'instance, l'objet en cours. Avec laquel nous sommes en train
 *      train de travailler, avec laquelle, on est peut être en train d'appeler une méthode.
 *      Avec la classe Vehicule, $this serait l'objet qui vient d'être créé et qui appele la méthode move().
 *      
 */
//En dehors de la classe ...
Database_01::connect();

/**
 *  #3# Créer une propriété static.
 *  --------------------------------
 *  On veux enregistrer le moteur de base de données utilisée avec $_storageName, notre système de gestion.
 */

class Database_02
{
   public static $_sgbd = 'MySQL'; // système de gestion de base de données.
   public static function connect()
   {
       echo 'Je me connecte ...';
   }
}

/**
 *  #4# Accéder à une propriété statique.
 *  -------------------------------------
 *  Toujours en public, si elle était privé, on ne pourrait pas y accéder.
 *  on va spécifier le nom de la classe et un operateur de résolution de portée (::) 
 *  et terminer par le nom de la méthode appelée.
 */

echo Database_02::$_sgbd;

/**
 *  #5# Application.
 *  ----------------
 *  Dans nos projets, nos classes où il n'y a pas beaucoup de méthodes, d'informations,
 *  ça ne vaut pas le coup d'instancier des objets. Il y a des cas où ce n'est pas utile de 
 *  le faire.
 * 
 *  On veux juste utiliser les méthodes de cette classe. 
 *  Exemple : 
 *      -> on ne fait pas de programmation d'objets.
 *      -> on a un simple fichier PHP avec plein de fonctions à se servir.
 *      -> les fonctions sont rassemblées par thème est définis par classe, le domaine des différentes méthodes.
 *      -> Database correspond à nos bases de données et contiendra toutes nos méthodes liées aux bases de données.
 *      -> Sans avoir besoin de créer d'instance, d'avoir des objets.
 *      -> l'appel de ces méthodes se fait de manière statique en spécifiant le mot clé static :
 *              -> dans les propriétés pour y accéder.
 *              -> dans la définition des méthodes pour pouvoir les appeler.
 * 
 */  