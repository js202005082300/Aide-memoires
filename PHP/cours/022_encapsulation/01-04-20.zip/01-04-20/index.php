<!--
    PHP #22 - encapsulation des données 
    https://www.youtube.com/watch?v=vrGedfJXUNo&list=
    
    accesseur = permet d'accéder ou modifier les attribut d'une classe.
    
    Type d'accesseurs avec lequels on parle d'accession :
        -> getter : lire un attribut. -> getAttribute
        -> setter : modifier un attribut.   -> setAttribute
    Tout ceci est le principe d'encapsulation.
        On passe par des méthodes pour travailler (lire ou modifier) avec nos attributs.
        On peux valider nos données avant de les enregistrées.

    Regle en PHP, on ne permet la lecture et la modification des attributs en dehors des classes.
    Même règle en C++ mais pas en Python. Certains langages nécessite de passer par des accesseurs.

-->
<?php
/*    
 *  Rappel schéma : 
 *    Une classe est une entité propre (class de Guerrier, Habitation et Vehicule).
 *    c'est une manière de programmer, l'objet.
 *    respect du partage de ces entités avec un accès limité à ces entités.
 *    sauf cas précis, les méthodes (ce que permettent de faire les objets) sont accessible publiquement.
 *    le mot clé public permet à nos méthodes, y compris le constructeur d'être public.
 *    sauf cas où le constructeur peut être privé, voir le design pattern Singleton.
 *    Généralement nous passons les attributs en privés, voir le mot clé protected en notion d'héritage.
 */
class Vehicule_01
{
    private $_name;
    private $_speed;

    public function __construct(string $name, int $speed)
    {
        $this->_name = $name;
        $this->_speed = $speed;
    }

    public function move()
    {
        echo 'Le Vehicule '.$this->_name.' se deplace a '.$this->_speed.'km/h.<br>';
    }
}

// Nous sommes en dehors de la classe.
$obj1 = new Vehicule_01('xc450', 650);
$obj1->move();

/*  $obj1->_name; --> ERROR FATAL due au principe d'encapsulation dont chaque classe représente 
    une sorte de boîte fermée avec un ensemble de manettes qui peuvent actionner leurs méthodes.
    Ce sont des manettes publics. Ce sont des méthodes qui font l'intermédiaire entre l'extérieur
    de la classe et l'accès aux attributs => méthodes spécifiques.
*/

/* 
 *  #1# Créer un getter.
 *  --------------------
 *  créer une méthode : public function.
 *  nommer cette méthode : getName().
 *  return la valeur de l'attribut.
 * 
 *  En bref, au sein de la classe, on a une méthode qui va se charger d'accéder à l'attribut.
 *  C'est le getter par défaut.
 *  
 *  Le getter retourne juste l'attribut. Puisqu'il s'agit d'une méthode (fonction de classe), 
 *  on peut mettre des conditions tel que interdire l'accès à _name.
 * 
 *  Dans la majorité des cas, on se contente de retourner l'attribut.
 * 
 */

class Vehicule_02
{
    private $_name;
    private $_speed;

    public function getName()
    {
        return $this->_name;
    }

    public function getSpeed()
    {
        echo 'Vitesse impossible à récupérer.<br>';
    }

    public function __construct(string $name, int $speed)
    {
        $this->_name = $name;
        $this->_speed = $speed;
    }
}

$obj2 = new Vehicule_02('xc450', 650);
$obj2->getName();
$obj2->getSpeed();

/* 
 *  #2# Créer un setter.
 *  --------------------
 *  On créer une méthode public qui prend en paramètre $name.
 *  On construit setName comme le constructeur.
 *  On peut installer certains filtres pour controler le nom passé en paramètre
 *      pour finalement stocker un nom valide (exemple avec strlen).
 * 
 *  Le setter permet de controler la validité ou non par un filtre au moment où on 
 *      veux stocker l'information.
 * 
 *  Très utile avec les formulaire en Web. On peux se servir d'une classe de contrôle
 *      les attributs de notre formulaire.
 *      
 *  En moyenne pour chaque attribut, un getter et un setter. Code minimal :
 *  getName()   -> return $this->_name;
 *  et
 *  setName(string $name) -> $this->_name = $name;
 *  
 *  Seconde règle en PHP, pour chaque attribut, un getter et un setter, pour garantir 
 *  cette encapsulation des données.
 *  
 */

class Vehicule_03
{
    private $_name;
    private $_speed;

    public function getName()
    {
        return $this->_name;
    }

    public function setName(string $name)
    {
        if(strlen($name) > 25)
            echo 'ERREUR : Nom de véhicule trop long.<br>'; // voir PHP #28 : Les exceptions.
        else
            $this->_name = $name; // si non, on stocke le nouveau nom.
    }


    public function __construct(string $name, int $speed)
    {
        $this->_name = $name;
        //$this->setName($name); --> dans l'ideal, on met un setter au niveau du constructeur pour vérifier le nom.
        $this->_speed = $speed;
        //$this->setSpeed($speed); --> appeler également la méthode à ce moment (méthode à faire).
    }
}

$obj3 = new Vehicule_03('xc450', 650);
$obj3->setName('xt3000<br>');
echo $obj3->getName();
$obj3->setName('xt3000zefgzjfizmfmqfiiqzjfqzjfqmzfjqzjfmiqfjqmfe'); // modification interrompue.
echo $obj3->getName();

/* 
 *  #3# Simplication du code.
 *  --------------------
 * 
 *  On met ensemble les accesseurs liées à l'attribut.
 */

class Vehicule_03
{
    private $_name;
    public function getName(){ return $this->_name; }
    public function setName(string $name){ $this->_name = $name; }

    private $_speed; // il faudrait pareil ici (un setter et un getter)
    //public ...

    public function __construct(string $name, int $speed)
    {
        $this->_name = $name;
        $this->_speed = $speed;
    }
}