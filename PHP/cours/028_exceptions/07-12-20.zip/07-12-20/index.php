<!--
    PHP #28 - exceptions
    https://www.youtube.com/watch?v=ePFxa2VcCoE
    Après avoir vu comment gérer les erreurs en PHP (séance 13), il 
    est temps d'aborder les exceptions, introduites avec la programmation 
    objet pour traiter des cas d'erreurs spécifiques dans vos applications web.
-->

<?PHP
/**
 *  Intro
 *  -----
 *  On a vu comment gérer les erreur avec du procédurale. 
 *  Mais PHP intègre en natif qui permet de gérer nos érreurs, appelé les exceptions.
 *  
 *  Exception : c'est une classe qui définis tout un tas d'erreur qui peuvent survenir 
 *  au niveau d'un code pour permettre de les traiter par la suite.
 * 
 *  Une exception peut intervenir dans plus cas (plusieurs types d'erreurs, plusieurs types
 *  d'exceptions) :
 *      -> exception produite lors d'une division par zéro (Fatal).
 *      -> accéder à un élément d'indice d'un tableau qui n'existe pas (Notice).
 *      -> échec de connection à la base de données.
 * 
 *  Les exceptions sont de la programmation objet et représente les avantages de ce 
 *  type de paradigme par rapport au procédurale. C'est la possibilité de réutiliser du code.
 * 
 */

//$res = 15 / 0;
//echo $res;

$tableau = [1,2,3];
echo $tableau[10];

echo '<br>';
/**
 *  #1# Provoquer une exceptions. => N'as pas fonctionner avec la division par zéro.
 *  -----------------------------
 *  Utilisation d'un bloc appelé le try catch.
 *  Le bloc try signifie qu'on va essayer de réaliser une opération qui pourrait provoquer une erreur.
 *  Le bloc catch permet de capturer l'exception que nous voulons.
 *      -> prend en paramètre une variable qui va capturer l'exception.
 *          -> exception de plusieurs types possibles : 
 *                  Exception : type de base, permet de capturer tout les types d'exception qui peut y avoir ;
 *                  TypeError ;
 *                  ParseError.
 *  L'erreur générer dans try{} est capturé dans le bloc exception global $e.
 *  La classe exception possède quelques méthodes :
 *      getMessage() affiche le message d'erreur qui est intervenus.
 *      getFile() affiche le fichier où il y a eu l'erreur.
 *      getLine() affiche la ligne où il y a eu l'erreur du fichier.
 *      getCode(), etc.
 *      ==> Ce sont des getter, des accesseur tel qu'on a vu en PHP, qui ici permettent de récupérer 
 *      informations d'exceptions.
 * 
 *  En bref, la classe exception est très simple à manipuler. Elle n'as pas grand chose en propriété méthodes.
 */

try 
{
    //$res = 15 / 0;
    //echo $res;
}

catch(Exception $e)
{
    echo $e->getMessage();
}

echo '<br>';

/**
 *  #2# Lever une exception manuellement.
 *  -------------------------------------
 *  Dans ce cas le try{} n'est pas obligatoire.
 * 
 *  On va lever une exception générale.
 *  Si $age est < 18, on lève une exception.
 *  levons (throw) une nouvelle instance de exception.
 *  C'est à dire qu'on crée une instance de la classe Exception. On crée un objet.
 *  On peut passer à notre constructeur Exception un message d'erreur.
 *  En fait si try{} lève une exception -> ca va rentrer dans le catch. 
 *  On capture ainsi toutes les exceptions possibles puisqu'elles ont le même type Exception.
 *  On les stockent dans $e, variable qui va stocker l'instance de l'exception qui a été levée.
 *  Comme tout les objets, on peut utiliser les méthodes de notre objet.
 */

$age = 17;

try 
{
    if($age < 18) // Si $age est < 18, on lève une exception.
        throw new Exception('Tu n\'es pas majeur.'); // levons (throw) une nouvelle instance de exception.
}

catch(Exception $e)
{
    echo $e->getMessage();
    echo $e->getFile(); // retourne le chemin de index.php qu'on est en train d'éxécuter.
}

echo '<br>';

/**
 *  #3# Cumuler les catch{}.
 *  ------------------------
 *  Pour la gestion des erreurs, nous devons utiliser les exceptions dans le cas du paradigme objet.
 *  On a peu d'exemples car on a vu peu de classes natives en objet en PHP.
 *  On a vu comment gérer et capturer une exception avec nos blocs try{} et catch{}.
 *  On a vu ensuite comment manuellement lever une exception.
 *  
 *  Fonctionnement : 
 *      Dans le bloc try{}, on essaye de faire quelque chose suceptible de lever 
 *      une exception (Si $age est < 18) et dans le bloc catch{}, on capture notre type.
 *      
 *  On peut capturer plusieurs type différent et les cumuler :
 *      -> Dans le bloc try{}, si une typeError ou une Exception est lévée, on rentre dans 
 *      des blocs différents.
 *      -> Sur la fin, on met toujours le bloc général 'Exception' pour capturer tout ce qui
 *      serait passé au travers avant.
 *      -> On peut cumuler les catch{} à la suite et on met dans le dernier catch le exception général
 *      pour capturer tout les types d'exceptions éventuellement.
 *          -> TypeError n'est pas un type d'exception, c'est un type d'erreur.
 *          -> PDOException est un type d'exception pour les bases de données.
 *          -> Exception capture tout ce qui n'est pas du PDOException.
 */

try 
{
    if($age < 18) // Si $age est < 18, on lève une exception.
        throw new Exception('Tu n\'es pas majeur.'); // levons (throw) une nouvelle instance de exception.
}

catch(TypeError $e)
{
    //...
}

catch(PDOException $e)
{
    //...
}

catch(Exception $e)
{
    echo $e->getMessage();
    echo $e->getFile(); // retourne le chemin de index.php qu'on est en train d'éxécuter.
}

echo '<br>';

/**
 *  #4# finally{}.
 *  --------------
 *  Bloc qui s'éxécute qu'il y ait une exception ou pas.
 *  Par exemple, si un fichier a pu être ouvert et qu'il y a une erreur, 
 *  on exécutera quand même la fermeture du fichier dans le finally{}.
 *  
 */

//finally
//{

//}

/**
 *  #5# créer sa propre classe étendue, spécialisée.
 *  ------------------------------------------------
 * 
 *  L'avantage avec le paradigme objet est la réutilisation du code.
 *  
 *  On a vu les type d'exception lorsqu'on divise par zéro ou qu'on déborde d'un tableau.
 *
 *  Et si maintenant, on veux valider le type d'é-mail d'un utilisateur. Si l'é-mail n'est
 *  pas valide, on veux gérer un type d'exception. En natif, PHP n'as pas créé un type 
 *  d'exception pour les é-mails. Il n'est pas possible de créer des milliers de classes
 *  d'exceptions pour chaque cas possible.
 * 
 *  => L'avantage de la réutilisation du code. A partir du moment où on a une classe, on peux
 *  étendre des classes selon la notion d'héritage. On peux également étendre des classes que
 *  l'on a pas nous même développer.
 *  => Exception est une classe PHP du quel on peux générer notre propre classe fille qui gère
 *  certaines types d'Exceptions particulières qui étendent la classe générale.
 *  => Toutes les méthodes et attributs en protected ou public dans la classe Exception serra utilisable
 *  par ma classe MyExceptionClass.
 *      => On peut utiliser la méthode getMessage() mais le mieux c'est que l'on peut redéfinir
 *      un constructeur Exception différent et ajouter de nouvelles méthodes.
 * 
 *  En conclusion, C'est le gros avantage de la programmation objet, c'est de pouvoir réutiliser du code. 
 *  Le code doit être générique, réutilisable car on ne pourra pas toucher tous les cas possible. 
 *  C'était impossible pour les créateur d'un langage de faire un type d'exception pour la validation d'un
 *  e-mail, la validation d'un code postal français, etc.
 * 
 *  Notre classe étend une classe générale et permet de spécifié les vérifications, etc. C'est tout l'intéret
 *  du système d'exception en PHP.
 */

class MyExceptionClass extends Exception
{
    //public function show_email_error_message(); // générer un message particulier pour une erreur su un email.
}

$email = 'tom@mail.com'; // L'utilisateur a saisi un email d'un formulaire que l'on stocke dans une variable email.
try // On fait le test de l'e-mail et on regarde si on lève une exception.
{
    //Traiter le mail, valider le mail avec filter_var().
    if(filter_var($email, FILTER_VALIDATE_EMAIL)) // Si on ne valide pas la syntaxe de l'email, on pourra lever notre exception.
        throw new MyExceptionClass('E-mail incorrect');
}
catch(MyExceptionClass $e)
{
    //echo $e->show_email_error_message(); // Vu que ca hérite de la classe Exception native de PHP, on peut soit utiliser notre méthode.
    echo $e->getMessage(); // On peut aussi utiliser toutes les méthodes hérité depuis la classe mère.
}

echo '<br>';

// d'autres méthodes ...

/*
 *  #6# Conclusion.
 *  ---------------
 * 
 *  Ce qui a été vu pendant la séance 13 reste en complément des exceptions à l'utilisation.
 * 
 *  Suivant ce qu'il est noté dans la doc et le retour de nos fonctions, on choisira les méthodes
 *  qui lèvent tel ou tel type d'exception. On peut récuperer des bibliothèques externe en PHP avec
 *  des méthodes qui lèvent tel ou tel exception.
 * 
 *  Le principe ici est d'utiliser cette méthode dans un bloc try{} catch{}.
 * 
 *  On met la partie sensible dans le bloc try{} => en cas de levée d'exception, on est sûr de
 *  capturer et de traiter l'erreur => On dois toujours traiter les erreurs dans un programme qui 
 *  risque de planter si une erreur survient.
 * 
 *  Deux vidéos pour la gestion des erreurs en procédurale (séance 13) et la gestion des exceptions
 *  qui sont des objets (séance 28), ce sont des classes en PHP que l'on peut étendre sans problème.
 */

/**
 *  #7# Définir un gestionnaire par défaut avec set_exception_handler().
 *  --------------------------------------------------------------------
 *  Si on ne fait pas de bloc try{} catch{} pour capturer mon exception, PHP va essayer
 *  d'utiliser le gestionnaire par défaut définis. C'est une façon de limiter la casse.
 *  Mais le plus propre reste de faire un bloc try{} catch{} pour gérer nos exceptions.
 * 
 *  Ici le code minimale à faire si on ne veux générer nos exceptions.
 */

function show_error($ex)
{
    echo 'ERROR : '.$ex->getMessage(); // voir le n° de lignes, un tableau, etc suivant le 
    //formatage que l'on veux.
}

/* Sans définir le gestionnaire par défaut qui suit, on obtiendra une erreur fatal.
 * C'est à dire 'Uncaught Exception' signifie qu'une exception n'as pas été capturé.
 */
set_exception_handler('show_error'); // définir le formatage par défaut.

throw new Exception("Utilisateur introuvable."); // lever une exception pour tester.

echo '<br>';
?>