<!--
    PHP #21 - attributs et méthodes
    https://www.youtube.com/watch?v=YCeS-4Z_wSk&list=
-->
<?php

/**
 *  Comment définir nos attributs et nos méthodes ?
 *  ------------------------------------------------
 *  les attributs (variables d'une classe) et les méthodes 
 *  (fonctions d'une classe) permettent d'enrichir les fonctionnalités 
 *  de vos objets.
 * 
 *  Attribut (ou propriété) : variable appartenant à une classe.
 *  Méthode                 : fonction appartenant à une classe.
 *      -> __construct() est une méthode particulière en programmation PHP avec "__".
 *      -> __destruct() => ne pas commencer nos méthode avec "__".
 */

/**
 *  #1# Définir des attributs (spécificités) pour déterminer ce que possède notre véhicule.
 *      -> commencer nos attribut de class par "$_" pour bien les différencier.
 *      -> public : toute les information déclaré public dans notre classe seront
 *          accessible depuis l'extérieur de cette classe, partout.
 *          Notre class Vehicle est une boîte fermé et tout ce qui est en public
 *          ouvre une porte vers l'extérieur.
 *      -> $obj1 est à l'extérieur de class peut accéder aux attribut déclaré public dans 
 *          la classe et je peux créer un nouvel objet, créer une nouvelle instance parce que
 *          le constructeur est public. Si le constructeur est privé, il faut passer par une 
 *          autre méthode, fonction public.
 *      -> Dans un cas réel, on n'aime pas que tout soit public, accessible partout.
 *      -> $_name : permet de définir un nom à notre objet au moment où on crée le véhicule.
 *      -> __construct(string $name) : fonctionne comme une fonction en procédurale et depuis PHP7,
 *          on peux donner un typage à nos fonctions.
 *      -> On peux définir une valeur par défaut à $name quand elle n'est pas précisée :
 *              -> string $name = false
 *              -> string $name = 'Undefined'
 *      -> Visuellement : 
 *              $_name est un attribut de classe (ajout d'un "_" pour les différencier).
 *              $name est variable.
 *      
 *          
 */

class Vehicle_01
{
    public $_name; // permet de définir un nom à notre objet au moment où on crée le véhicule.
    
    public function __construct(string $name) // depuis PHP7, on peut définir les types de variables (ne pas hésitez à s'en servir).
    {
        $this->_name = $name; 
        /* stocker dans la class avec la variable $this vers mon attribut sans $
        auquel on affecte la variable name.*/
    }
}

$obj1 = new Vehicle_01('Mon bolide'); // le constructeur attend une chaîne de caractères.

/* #2# accéder (et afficher) à un attribut.*/
echo $obj1->_name; // afficher l'attribut $_name à l'objet obj1 (que à lui).
echo $obj1->_name.'<br>'; // Avec la balise HTML, il faut fermer la balise PHP.

$obj2 = new Vehicle_01('Mon autre bolide'); // second objet différent.
echo $obj2->_name.'<br>'; // appeler l'attribut name sur ce second objet.



/*  Regle : Les attribut sont toujours privé.
 *  -----------------------------------------
 * 
 *  Ne jamais accéder aux attribut et les modifier en dehors de la classe.
 *  Si l'attribut prend le mot clé 'private', le renomage en dehors de la class provoque
 *  une erreur fatale car l'accès à un attribut privé est interdit.
 * 
 *  private signifie que l'attribut n'est pas accessible en dehors de la class.
 *  Par contre le constructeur a le droit d'accéder à la classe. Les méthodes
 *  sont des services que propose la class, elles doivent bien être accessibles.
 *  
 *  Plus tard, on crée des méthodes, des accesseurs pour modifier nos attributs. 
 *  Ces méthodes sont public.
 * 
 *  NB :
 *  protected est un autre mot clé que private ou public en lien avec la notion d'héritage.
 *  L'héritage permet de créer des class qui hérite d'une classe mère.
 *  protected permet l'accès aux éléments aussi bien pour la classe fille que la mère.
 *  Elles pourront communiquer entre elles puisqu'elles font partie de la même famille.
 * 
 *  Par définition, l'attribut est généralement privé et la méthode généralement public.
 * 
 */
$obj1->_name = 'Nouveau nom'; // ERREUR FATAL : ce comportement devrait être réservé pour la classe.
echo $obj1->_name.'<br>';

class Vehicle_02
{
    private $_name; // Définir un attribut, une propriété. l'attribut doit toujours être en privé.
    public function __construct(string $name) 
    {
        $this->_name = $name; // Renseigner une information via le constructeur.
    }
}

/*  Comment définir une méthode ?
 *  -----------------------------
 *  On définis une méthode avec le mot clé public.
 *  On définis le mot clé function.
 *  on définis un nom.
 */

class Vehicle_03
{
    // Définition un attribut.
    private $_name; 
    public function __construct(string $name) 
    {
        $this->_name = $name; // Renseigner une information via le constructeur.
    }
    // Définition d'une méthode.
    public function hello()
    {
        echo 'Hello :) !'.'<br>';
    }
    public function move()
    {
        echo 'Le vehicule se deplace ...'.'<br>';
        echo $this->_name.' se deplace ...'.'<br>'; // Tout ce qui est dans la class, peut accéder à ses élément privé.
    }
}

$obj3 = new Vehicle_03('Mon super bolide');

/*  Comment utiliser une méthode ?
 *  -----------------------------
 *  Utiliser une flèche comme pour les attributs.
 *  Si la méthode a des argument, il faut la renseigné comme pour le constructeur.
 */

$obj3->hello();
$obj3->move();

/*  Regle : L'intéret.
 *  ------------------
 *  On a pas envie que l'utilisateur accède à nos attributs.
 * 
 *  Les accesseurs permettent de dire de quel manière on accède 
 *  aux attributs et de quels manières on peut les modifier.
 * 
 *  Les set up permettent de dire par exemple que le nom d'un véhicule ne
 *  dois dépasser 25 caractères OU alors qu'il ne dois pas contenir de numéro, etc.
 *  Permettent de mettre des filtres de vérification pour la cohérence des données.
 * 
 *  C'est pour ça qu'en programmation objet, les attributs sont privés et les méthodes 
 *  sont publics.
 *  
 *  Les méthodes sont les seules choses qu'on peut appeler de l'extérieur avec nos objets.
 */

/*  Note : Plusieurs attributs possible pour une class.
 *  ---------------------------------------------------
 */

class Vehicle_04
{
    private $_name; 
    private $_power; 

    public function __construct(string $name, int $power) 
    {
        $this->_name = $name;
        $this->_power = $power;
    }
    public function hello()
    {
        echo 'Hello, ';
        echo $this->_name.' se deplace à la vitesse de '.$this->_power.'<br>';
    }
}

$obj4 = new Vehicle_04('Mon super bolide ', 650);
$obj4->hello();

?>