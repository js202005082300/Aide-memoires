<?php
    /** 28-03-20
     *  Comment créer une classe et l'instancier pour former des objets.
     *  ----------------------------------------------------------------
     *  Vu en procédurale : difinition de plusieurs fonctions en factorisant,
     *  rassembler du code répété dans notre programme au sein d'une fonction.
     *  Il suffisait ensuite de faire appel à ces fonctions. C'est un des paradigmes
     *  que propose PHP.
     * 
     *  Ilustration :
     *  On peux définir ces notions par un ensemble d'entités.
     *  Une classe va définir une entité au sein de notre application.
     *  Exemple dans un Jeux : 
     *      - Guerrier est une entité de notre jeux vidéo. 
     *      - Il pourrait y avoir une classe pour : Donjons, inventaire, monstres, etc.
     *      - Habitation est une classe qu'on pourrait retrouver dans les hopitaux par exemple
     *          avec une classe pour définir médecin, les patients, les établissements, les services, etc.
     *      - Véhicule définis également une entité.
     *  Ces entités sont définies par des boîtes par un programmeur qui a définis des fonctions de classes (=méthode).
     *  Les informations de cette classes (=variables) sont appelées des attributs (ou propriétés pour PHP) en objet.
     *  Dans d'autres langages, on n'appelle pas forcément ces variables des propriétés.
     *  
     *  La classe, c'est l'entité représenté, le modèle qu'elle doit suivre.
     *  Elle a des méthodes, qui sont des services, ce que propose la classe (Le guerrier 
     *  est capable de se déplacer, son premier service, et il est capable d'attaquer).
     *  Elle a des attributs, des spécificités (Le Guerrier : piecesOr et pointsDeVie).
     * 
     *  Le développeur crée la classe et l'utilisateur, c'est le développeur qui utilise
     *  les classes créées par d'autres développeurs. Nous avons besoin de savoir les services
     *  qu'elles proposent (ses méthodes) et ses spécificités, ce qui la définis, ces attributs.
     *  L'utilisateur peut alors utiliser la classe Guerrier, Habitation et Véhicule.
     * 
     *  Il faut distinguer l'utilisateur développeur de l'utilisateur final. L'utilisateur développeur
     *  se sert de certaines classes pour son propre développement de site web à coté du développement 
     *  de ses propres classes qui partiront de rien pour définir nos propres entités.
     */

    /*  
     *  #1# Comment créer/définir notre classe (Comment définir une classe ?).
     *  class :
     *      -> mot clé au début de la classe.
     *      -> nommage : pas de caractères accentuées, caractères spéciaux, d'espace 
     *                  Mais une majuscule en début de chaque nouveau mot.
     *                  Nommer en anglais. 
     *      -> On ne crée pas ici de méthode, on ne définis pas ses attributs.
     */


class Vehicle_01
{

}

    /*  
     *  #2# Instancier/créer un objet de notre classe 
     *  (Comment construire cette instance, construire un objet grâce au constructeur ?)
     *  La classe est le modèle qui dit comment est composé un véhicule.
     *  Ici on crée une version concréte de ce véhicule qu'on stocke dans une variable,
     *  qui représentera notre objet.
     * 
     *  Chaque objet (obj1 et obj2) est indépendant l'un de l'autre.
     */

$obj1 = new Vehicle_01(); // PHP a construit une instance en créant cet objet.
$obj2 = new Vehicle_01(); // Une autre instance de classe.

    /*  
     *  #3# Définir un constructeur.
     *  Le constructeur est une fonction qui s'appelle 'construct' qui dit 
     *  comment construction un objet de classe 'Vehicle'.
     * 
     *  On rappelle autant de fois le constructeur qu'on crée d'instance.
     * 
     *  A la fin du programme, les objets sont détruits à l'inverse de l'ordre qu'ils
     *  ont été créés (obj4 est détruit en premier et obj1 en dernier). C'est PHP qui gère 
     *  la destruction des objets. PHP est un langage beaucoup plus haut niveau que C ou C++.
     * 
     *  C'est à dire que PHP va pouvoir lui-même libérer la mémoire proprement.
     */

class Vehicle_02
{
    public function __construct() // fonction sans attributs.
    {
        echo 'Je  suis construit !';
    }
}

$obj3 = new Vehicle_02();
$obj4 = new Vehicle_02(); // seconde instance crée en rappellant le constructeur.

    /*  
     *  #4# Définir la méthode pour le destructeur.
     *  Parfois on peut définir nous-même la méthode pour le destructeur pour 
     *  définir des manipulations précises au moment ou on détruit un objet.
     * 
     *  Par défaut, PHP utilise son système de destruction. 
     *  En pratique, on ne définis pas le destructeur sauf si on veux définir 
     *  un comportement différent.
     */ 

class Vehicle_03
{
    public function __construct()
    {
        echo 'Je  suis construit !';
    }

    public function __destruct() // méthode avec un nom spécial (double underscore).
    {
        echo 'Je  suis détruit !';
    }
}

$obj5 = new Vehicle_02();
$obj6 = new Vehicle_02(); 

    /*  
     *  #5# La variable $this.
     * 
     *  Comment dire à mon objet de tourner à droite ?
     *  
     *  On stocke des objets dans des variables pour les identifier.
     *  Exemple, si on veux tourner l'objet à droite, on le fera avec
     *  notre variable.
     *  Les variables ne se mélange pas.
     * 
     *  La class va créer une seconde variable qui s'appelle 'this' qui représente
     *  l'instance courante.
     * 
     *  Exemple, obj7, tu va utiliser une des instance de ma class et bien PHP va pouvoir
     *  identifié à quel objet appartient cet objet en mémoire. PHP ne connais pas obj1 et obj2,
     *  il identifie l'endroit de l'objet avec cette variable secondaire $this.
     * 
     *  Exemple, je dit dans mon constructeur que je veux tourner à droite s'écrit :
     *  $this->tournerADroite();
     * 
     *  Pas besoin de se soucier qu'es qui va tourner car ce sera automatiquement l'objet
     *  qui a été instancié, l'objet appelant.
     * 
     *  $obj7 est instancié, ensuite PHP arrive au constructeur et il sera que $this correspond
     *  à obj7.
     *  
     *  La petite variable $this en PHP fait référence à l'objet en cours, l'instance en cours d'utilisation.
     *  
     *  
     */

    class Vehicle_04
    {
        /* $this */
        
        public function __construct()
        {
            echo 'Je  suis construit !';
            //$this->tournerADroite();
        }
    
        /* tournerADroite() */
    }
    
    $obj7 = new Vehicle_02();
    $obj8 = new Vehicle_02(); 

    /*  
     *  #6# Autre manière d'instancier un objet.
     * 
     *  Permis seulement par PHP.
     * 
     *  Permet de gérer l'instanciation de class de manière dynamique.
     *  sans même connaître le nom car il a été stocké dans un fichier
     *  par exemple. On peut ensuite récupérer le nom dans un variable.
     * 
     *  On peut faire également des instanciation via un mot clé static.
     * 
     *  Le mot clé new permet de créer une nouvel instance et on peux le faire
     *  avec des variables.
     *  
     */

$name = 'Vehicle';
$obj9 = new $name(); // remplacer $name par le contenu de la variable.
?>