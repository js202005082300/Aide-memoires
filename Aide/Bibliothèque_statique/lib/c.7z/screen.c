#include "screen.h"
#include "point.h"
#include <stdio.h>

Screen initScreen(int w, int h)
{
    Screen scr = {w, h, false};
    return scr;
}

void powerOnScreen(Screen* scr)
{
    if(!scr->isOn)
    {
        scr->isOn = true;
        puts("Allumage de l'ecran...");
    } 
}

void powerOffScreen(Screen* scr)
{
    if(!scr->isOn)
    {
        scr->isOn = false;
        puts("Extinction de l'ecran");
    } 
}

void drawPointOnScreen(Screen* scr, Point* pt)
{
    if(pt->x >= 0 && pt->x < scr->width && pt->y >= 0 && pt->y < scr->height)
        printf("Un point est dessine aux coordonnees (%d, %d) de l'ecran.\n", pt->x, pt->y);
}