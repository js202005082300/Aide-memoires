#include "color.h"
#include "screen.h"

Point createPoint(int x, int y, Color* c)
{
    Point pt = {*c, x, y};
    return pt;
}